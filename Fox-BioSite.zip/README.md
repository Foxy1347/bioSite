<h1>CSD 340 Web Development with HTML and CSS</h1>

<h2>Contributors</h2>

<ul>
	<li>Professor Sue Sampson</li>
	<li>Shane Fox</li>
</ul>
